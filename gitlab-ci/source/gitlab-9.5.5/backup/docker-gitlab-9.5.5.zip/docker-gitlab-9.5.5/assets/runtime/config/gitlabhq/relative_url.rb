# Relative URL support
# WARNING: We recommend using an FQDN to host GitLab in a root path instead
# of using a relative URL.
# Documentation: http://doc.gitlab.com/ce/install/relative_url.html
# Copy this file to relative_url.rb and customize it to run in a non-root path
#

Rails.application.configure do
  config.relative_url_root = "{{GITLAB_RELATIVE_URL_ROOT}}"
end
